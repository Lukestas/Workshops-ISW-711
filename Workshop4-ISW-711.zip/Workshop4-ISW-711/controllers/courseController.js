const Course=require("../models/coursemodel");

const courseCreate=(req,res)=>{
    let course=new Course();

    course.name=req.body.name;
    course.code=req.body.code;
    course.description=req.body.description;
    course.teacher=req.body.teacher;

    if (course.name&&course.code){
        course.save().then(()=>{
            res.status(201);
            res.header({
                "location":`/courses/?id=${course.id}`
            })
            res.json(course);
        }).catch((error)=>{
            res.status(422)
            res.json({
                error: "There was an error saving the course"
            });
        });
    }else{
        res.status(422)
        res.json({
            error:"No valid data for provided for course"
        });
    };
};

const courseGet=(req,res)=>{
    if (req.query&&req.query.id){
        Course.findById(req.query.id).then()
    }
}
